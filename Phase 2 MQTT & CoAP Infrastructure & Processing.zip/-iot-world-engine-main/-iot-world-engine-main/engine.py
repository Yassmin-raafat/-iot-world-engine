import asyncio
import random
import json
import sqlite3
import time
import os
from gmqtt import Client as MQTTClient

BROKER = os.getenv("MQTT_BROKER", "hivemq")

CONFIG = {
    "num_floors": 10,
    "rooms_per_floor": 20,
    "light_threshold": 500,
    "tick_interval": 5,
    "save_every_ticks": 6,
    "outside_temp_day": 34.0,
    "outside_temp_night": 22.0,
    "alpha": 0.01,
    "beta": 0.2,
    "heartbeat_timeout": 60
}


def init_db():
    conn = sqlite3.connect("rooms.db")
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rooms (
        room_id TEXT PRIMARY KEY,
        last_temp REAL,
        last_humidity REAL,
        hvac_mode TEXT,
        target_temp REAL,
        last_update INTEGER,
        protocol TEXT
    )
    """)

    conn.commit()
    conn.close()


def save_room(room):
    conn = sqlite3.connect("rooms.db")
    cursor = conn.cursor()

    cursor.execute("""
    INSERT OR REPLACE INTO rooms
    (room_id, last_temp, last_humidity, hvac_mode, target_temp, last_update, protocol)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        room.room_id,
        room.temperature,
        room.humidity,
        room.hvac_mode,
        room.target_temp,
        int(time.time()),
        room.protocol
    ))

    conn.commit()
    conn.close()


def load_rooms():
    conn = sqlite3.connect("rooms.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM rooms")
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_outside_temp():
    hour = time.localtime().tm_hour
    if 6 <= hour < 18:
        return CONFIG["outside_temp_day"]
    return CONFIG["outside_temp_night"]


class Room:
    def __init__(self, building_id, floor_id, room_id, protocol):
        self.building_id = building_id
        self.floor_id = floor_id
        self.room_id = room_id
        self.protocol = protocol

        self.temperature = 22.0
        self.humidity = 50.0
        self.occupancy = False
        self.hvac_mode = "OFF"
        self.light_level = 300
        self.lighting = "OFF"
        self.target_temp = 22.0

    def update(self, outside_temp):
        if random.random() < 0.01:
            return

        self.occupancy = random.choice([True, False])

        leakage = CONFIG["alpha"] * (outside_temp - self.temperature)

        if self.hvac_mode == "ON":
            if self.temperature < self.target_temp:
                hvac_effect = CONFIG["beta"]
            elif self.temperature > self.target_temp:
                hvac_effect = -CONFIG["beta"]
            else:
                hvac_effect = 0.0
        elif self.hvac_mode == "ECO":
            if self.temperature < self.target_temp:
                hvac_effect = CONFIG["beta"] * 0.5
            elif self.temperature > self.target_temp:
                hvac_effect = -CONFIG["beta"] * 0.5
            else:
                hvac_effect = 0.0
        else:
            hvac_effect = 0.0

        occupancy_heat = 0.1 if self.occupancy else 0.0

        self.temperature = self.temperature + leakage + hvac_effect + occupancy_heat
        self.humidity += random.uniform(-0.5, 0.5)

        if self.occupancy:
            self.light_level = random.randint(600, 1000)
        else:
            self.light_level = random.randint(50, 300)

        if self.occupancy and self.light_level < CONFIG["light_threshold"]:
            self.lighting = "ON"
        else:
            self.lighting = "OFF"

        if random.random() < 0.02:
            self.temperature += 0.3

        self.temperature = max(15.0, min(50.0, self.temperature))
        self.humidity = max(0.0, min(100.0, self.humidity))
        self.light_level = max(0, min(1000, self.light_level))

    def get_topic(self):
        room_num = self.room_id.split("-")[-1].replace("r", "")
        return f"campus/bldg_01/floor_{self.floor_id:02d}/room_{room_num}/telemetry"

    def get_command_topic(self):
        room_num = self.room_id.split("-")[-1].replace("r", "")
        return f"campus/bldg_01/floor_{self.floor_id:02d}/room_{room_num}/cmd"

    def to_dict(self):
        return {
            "sensor_id": self.room_id,
            "protocol": self.protocol,
            "timestamp": int(time.time()),
            "temperature": round(self.temperature, 2),
            "humidity": round(self.humidity, 2),
            "occupancy": self.occupancy,
            "light_level": self.light_level,
            "hvac_mode": self.hvac_mode,
            "lighting_dimmer": 100 if self.lighting == "ON" else 0
        }

    def to_json(self):
        return json.dumps(self.to_dict())


ROOMS_MAP = {}


def on_message(client, topic, payload, qos, properties):
    try:
        data = json.loads(payload.decode() if isinstance(payload, bytes) else payload)
    except Exception:
        print(f"[MQTT CMD] Invalid payload on {topic}: {payload}")
        return

    for room in ROOMS_MAP.values():
        if room.get_command_topic() == topic and room.protocol == "MQTT":
            if "hvac_mode" in data:
                room.hvac_mode = data["hvac_mode"]
            if "target_temp" in data:
                room.target_temp = float(data["target_temp"])

            print(
                f"[MQTT CMD] {room.room_id} updated -> "
                f"hvac_mode={room.hvac_mode}, target_temp={room.target_temp}"
            )
            save_room(room)
            return

    print(f"[MQTT CMD] No matching MQTT room for topic {topic}")


async def publish_mqtt_room(room, client):
    topic = room.get_topic()
    payload = room.to_json()
    client.publish(topic, payload)

    heartbeat_topic = topic.replace("telemetry", "heartbeat")
    client.publish(heartbeat_topic, json.dumps({
        "room_id": room.room_id,
        "status": "alive",
        "protocol": room.protocol,
        "timestamp": int(time.time())
    }))


async def publish_coap_room(room):
    print(f"[COAP NODE] {room.room_id} -> {room.to_json()}")


async def connect_mqtt_with_retry(client, broker):
    while True:
        try:
            await client.connect(broker)
            print(f"Connected to broker: {broker}")
            return
        except Exception as e:
            print(f"Waiting for broker {broker} ... {e}")
            await asyncio.sleep(5)


async def room_loop(room, client):
    await asyncio.sleep(random.uniform(0, CONFIG["tick_interval"]))
    counter = 0

    while True:
        start = time.perf_counter()

        if random.random() < 0.01:
            print(f"{room.room_id} | DROPOUT simulated")
            await asyncio.sleep(CONFIG["heartbeat_timeout"] + 5)
            continue

        outside_temp = get_outside_temp()
        room.update(outside_temp)

        if room.protocol == "MQTT":
            await publish_mqtt_room(room, client)
        else:
            await publish_coap_room(room)

        print(
            f"{room.room_id} | Protocol: {room.protocol} | "
            f"Temp: {round(room.temperature, 2)} | "
            f"Humidity: {round(room.humidity, 2)} | "
            f"Light: {room.light_level} | LED: {room.lighting} | HVAC: {room.hvac_mode}"
        )

        counter += 1

        if counter % CONFIG["save_every_ticks"] == 0:
            save_room(room)

        processing_time = time.perf_counter() - start
        actual_sleep = max(0, CONFIG["tick_interval"] - processing_time)
        await asyncio.sleep(actual_sleep)


async def main():
    init_db()
    saved_data = load_rooms()
    saved_map = {row[0]: row for row in saved_data}

    client = MQTTClient("world-engine-phase2")
    client.on_message = on_message

    await connect_mqtt_with_retry(client, BROKER)

    rooms = []

    for floor in range(1, CONFIG["num_floors"] + 1):
        for r in range(1, CONFIG["rooms_per_floor"] + 1):
            room_number = floor * 100 + r
            room_id = f"b01-f{floor:02d}-r{room_number:03d}"

            protocol = "MQTT" if room_number % 2 == 0 else "COAP"
            room = Room("b01", floor, room_id, protocol)

            if room_id in saved_map:
                row = saved_map[room_id]
                room.temperature = row[1]
                room.humidity = row[2]
                room.hvac_mode = row[3]
                room.target_temp = row[4]

            ROOMS_MAP[room_id] = room
            rooms.append(room)

    for room in rooms:
        if room.protocol == "MQTT":
            client.subscribe(room.get_command_topic())
            print(f"[SUBSCRIBED] {room.get_command_topic()}")

    print(f"Total rooms: {len(rooms)}")
    print(f"MQTT rooms: {len([r for r in rooms if r.protocol == 'MQTT'])}")
    print(f"COAP rooms: {len([r for r in rooms if r.protocol == 'COAP'])}")

    tasks = [asyncio.create_task(room_loop(room, client)) for room in rooms]
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Shutting down cleanly...")