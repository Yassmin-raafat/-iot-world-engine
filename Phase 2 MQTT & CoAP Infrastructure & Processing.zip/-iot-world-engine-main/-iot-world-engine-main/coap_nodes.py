import json

async def publish_coap_room(room):
    payload = json.loads(room.to_json())
    print(f"[COAP NODE] {room.room_id} -> {payload}")