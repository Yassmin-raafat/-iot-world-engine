import json
import time

async def publish_mqtt_room(room, client):
    topic = room.get_topic()
    payload = room.to_json()

    client.publish(topic, payload)

    heartbeat_topic = topic.replace("telemetry", "heartbeat")
    client.publish(heartbeat_topic, json.dumps({
        "room_id": room.room_id,
        "status": "alive",
        "timestamp": int(time.time())
    }))